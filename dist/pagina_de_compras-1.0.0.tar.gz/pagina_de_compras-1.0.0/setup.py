from setuptools import setup, find_packages

setup(
    name='pagina_de_compras',
    version='1.0.0',
    description='Segunda Pre-Entrega',
    author='Santino Bergamo',
    author_email='santinobergamo@gmail.com',
    packages=find_packages(),
    install_requires=[],
)
